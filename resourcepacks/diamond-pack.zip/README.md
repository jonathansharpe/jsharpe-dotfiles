# Resource Pack Template

- Use this to start a resource pack, other formats are on seperate branches.
- Download the pack format version you need from the [releases page](https://github.com/Love-and-Tolerance/Resource-Pack-template/releases/latest). 
