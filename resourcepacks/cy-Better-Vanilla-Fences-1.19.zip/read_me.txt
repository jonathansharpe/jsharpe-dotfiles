All models were designed by me, Chancellor Yusuf (previously CheesyGoodness)
These models will work with any resource pack.

You may not reupload this resource pack.

I only release resource packs on Planet Minecraft and CurseForge.
If you got it anywhere else, I did not approve.